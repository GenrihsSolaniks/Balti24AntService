<?php
header('Content-Type: application/json');

// Подключение к базе данных
$mysql = new mysqli('localhost', 'root', '', 'balti24db');
if ($mysql->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Ошибка подключения к базе данных']);
    exit();
}

// Получение данных из запроса
$data = json_decode(file_get_contents('php://input'), true);
$orderId = $data['id'] ?? null;
$action = $data['action'] ?? null;

if (!$orderId || !$action) {
    echo json_encode(['success' => false, 'message' => 'Неверные данные']);
    exit();
}

// Проверяем действие
if ($action === 'publishOrder') {
    $query = "UPDATE tasks SET status = 1 WHERE id = $orderId";
    if ($mysql->query($query)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Ошибка выполнения запроса: ' . $mysql->error]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неизвестное действие']);
}

$mysql->close();
?>
